export default function App() {
  return <main>Hello from the downloaded mock project.</main>;
}
