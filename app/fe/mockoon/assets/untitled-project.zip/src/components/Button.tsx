export function Button() {
  return <button>Mock Button</button>;
}
